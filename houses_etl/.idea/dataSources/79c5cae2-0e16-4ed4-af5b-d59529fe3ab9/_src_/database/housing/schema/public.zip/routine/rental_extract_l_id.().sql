create function rental_extract_l_id() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
		INSERT INTO staging.test ("ListingId", job_run_datetime) VALUES ((SELECT "ListingId" FROM staging.tm_rental_listings_daily_test), (SELECT "job_run_datetime" FROM staging.tm_rental_listings_daily_test));
        RETURN Null;
    END
$$;
