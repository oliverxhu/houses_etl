create function residential_extract_id() returns void
LANGUAGE plpgsql
AS $$
BEGIN
    	INSERT INTO dev.tm_residential_listing_id_hourly ("ListingId", job_run_datetime)
        SELECT "ListingId", job_run_datetime
        FROM staging.tm_residential_listings_hourly
        GROUP BY "ListingId", job_run_datetime;
    END;

$$;
